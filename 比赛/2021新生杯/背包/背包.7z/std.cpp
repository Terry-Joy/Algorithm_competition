#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<ctime>
using namespace std;
typedef long long ll;
const int N=510,M=30000010,LEN=6000010;
ll m,f[M],ans;int n,i,cnt;
int ST,EN;
struct P{
    ll w,v;
    P(){}
    P(ll _w,ll _v){w=_w,v=_v;}
}a[N],b[LEN],c[LEN],d[LEN];
inline bool cmp(const P&a,const P&b){return a.w==b.w?a.v>b.v:a.w<b.w;}
inline void up(ll&a,ll b){a<b?(a=b):0;}
inline void add(ll w,ll v){
    if(clock()>EN)return;
    int cc=0;
    for(int i=1;i<=cnt;i++){
        if(w+b[i].w<=m){
            c[++cc]=P(w+b[i].w,v+b[i].v);
        }
    }
    int i=1,j=1,k=0;
    while(i<=cnt&&j<=cc){
        d[++k]=cmp(b[i],c[j])?b[i++]:c[j++];
    }
    while(i<=cnt)d[++k]=b[i++];
    while(j<=cc)d[++k]=c[j++];
    int o=0;
    for(int i=1;i<=k;i++)if(i==1||d[i].v>b[o].v)b[++o]=d[i];
    //cnt=min(o,1000000/n);
    cnt=min(o,LEN/2-5);
    up(ans,b[cnt].v);
}
ll cal(ll m){
    ll ratio=(double)(n)*(double)(m)/M;
    ratio=max(ratio,1LL);
    m/=ratio;
    for(i=0;i<n;i++){
        ll w;ll v;
        scanf("%lld%lld",&w,&v);
        a[i].w=w;
        a[i].v=v;
        w/=ratio;
        int j;
        for(j=m;j>=w;j--)up(f[j],f[j-w]+v);
    }
    for(i=0;i<=m;i++)up(ans,f[i]);
}
int main(){
    ST=clock();
    EN=ST+3.7*CLOCKS_PER_SEC;
    scanf("%d%lld",&n,&m);
    if(!n)return puts("0"),0;
    if(m<M&&1LL*n*m<2e8){
        while(n--){
            int w;ll v;
            scanf("%d%lld",&w,&v);
            for(i=m;i>=w;i--)up(f[i],f[i-w]+v);
        }
        for(i=0;i<=m;i++)up(ans,f[i]);
        printf("%lld",ans);
        return 0;
    }
    ans=cal(m);
    random_shuffle(a,a+n);
    b[cnt=1]=P(0,0);
    for(i=0;i<n;i++)add(a[i].w,a[i].v);
    printf("%lld",ans);
}
