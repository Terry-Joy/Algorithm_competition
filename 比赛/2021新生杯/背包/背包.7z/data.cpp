#include<bits/stdc++.h>
using namespace std;
using ll=long long;
unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
mt19937 rand_num(seed);  // 大随机数
uniform_int_distribution<long long> WW(0,100000000000000000);
uniform_int_distribution<long long> vi(0,10000000000000000);
// 给定范围
uniform_int_distribution<int>dist(0,500);
int main(){ 
    int n;
    ll W;
    W=WW(rand_num);
    n=dist(rand_num);
    cout<<n<<" "<<W<<"\n";
    for(int i=1;i<=n;++i){ 
        ll wi=min(WW(rand_num),W);
        ll v=vi(rand_num);
        cout<<wi<<" "<<v<<"\n";
    }
    return 0;
}
